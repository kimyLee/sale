* What operating system are you using? 
* What version of Node.js is on your system?
