/**
 * Created by duoyi on 2016/9/8.
 */
/**
 * Created by duoyi on 2016/9/8.
 */
import html from './template.html'

export default {

    template: html,

    replace: true,

    props: {

    },

    data () {
        return {

        }
    },

    ready (){
        console.log("hello2");
    }
}