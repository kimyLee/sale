/**
 * Created by kimy on 2016/5/21.
 */
'use strict';
var Vue = require('vue');
var App=require("./tpl/app.vue");

new Vue(App);